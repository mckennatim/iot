# Learn ESP32 with Arduino IDE Course

Official course page: http://randomnerdtutorials.com/learn-esp32-with-arduino-ide
